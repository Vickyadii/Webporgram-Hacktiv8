    <!-- Judul Algoritma : Menghitung Luas dan Keliling Lingkaran

    Logika Luas Lingkaran :
    1. Deklarasi dan Mencari nilai phi dan jari-jari
    2. Phi * ( jari-jari * jari-jari )
    3. Keluarkan Hasil Output

    Logika Keliling Lingkaran :
    1. Deklarasi dan Mencari nilai Phi dari jari-jari
    2. Menggunakan Jari-jari (r):
    Keliling (C) = 2πr
    Di mana π (pi) adalah konstanta matematika yang biasanya diperhitungkan sebagai 3,14159 atau lebih.
    3. Keluarkan Hasil Output -->

    <!-- Dibuat Oleh Vicky Priyadi -->